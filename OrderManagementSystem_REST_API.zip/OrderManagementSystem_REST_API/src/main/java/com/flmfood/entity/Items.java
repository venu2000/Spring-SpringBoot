package com.flmfood.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "Items")
@Data
public class Items {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int itemId;
	
	private String itemName;
	
	@Column(nullable=true)
	private double price;
	
	private int quantity;
	
	private double rating;
	
	private double discount;

	public Items(String itemName, double price, int quantity, double rating, double discount) {
		super();
		this.itemName = itemName;
		this.price = price;
		this.quantity = quantity;
		this.rating = rating;
		this.discount = discount;
	}
	
	
	
	
	
	
	

}
