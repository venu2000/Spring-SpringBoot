package com.flmfood.Service;

public interface ItemService {

}
